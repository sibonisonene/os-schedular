#include <iostream>
#include <limits>

using namespace std;

class TreeNode
{
public:
    // Pointer to the left child
    //  Initialised to nullptr
    TreeNode *left = nullptr;
    // Pointer to the right child
    //  Initialised to nullptr
    TreeNode *right = nullptr;

    // Value in the node
    int value;

    // Constructor, sets the value
    TreeNode(int v) : value(v) {}
};

class Tree
{
public:
    TreeNode *root = nullptr;

    // Insert works correctly
    void insert(int v)
    {
        insert(v, root);
    }
    void insert(int v, TreeNode *&subtree)
    {
        if (subtree == nullptr)
        {
            subtree = new TreeNode(v);
        }
        else if (v < subtree->value)
        {
            insert(v, subtree->left);
        }
        else
        {
            insert(v, subtree->right);
        }
    }

    ////////////////////////////////////////////////////
    // Question 1 -- Traversals
    void preOrderTraversal()
    {
        preOrderTraversal(root);
        cout << endl;
    }
    void inOrderTraversal()
    {
        inOrderTraversal(root);
        cout << endl;
    }
    void postOrderTraversal()
    {
        postOrderTraversal(root);
        cout << endl;
    }
    void preOrderTraversal(TreeNode *subtree)
    {

    }
    void inOrderTraversal(TreeNode *subtree)
    {

    }
    void postOrderTraversal(TreeNode *subtree)
    {

    }

    ////////////////////////////////////////////////////
    // Question 2 -- Descending Order
    void descendingOrder()
    {
        descendingOrder(root);
        cout << endl;
    }
    void descendingOrder(TreeNode *subtree)
    {

    }

    ////////////////////////////////////////////////////
    // Question 3 -- Depth of value
    void depth(int value)
    {
        cout << depth(root, value) << endl;
    }
    int depth(TreeNode *subtree, int value)
    {

    }

    ////////////////////////////////////////////////////
    // Question 4 -- Internal Nodes
    void internalNodes()
    {
        cout << internalNodes(root) << endl;
    }
    int internalNodes(TreeNode *subtree)
    {

    }

    ////////////////////////////////////////////////////
    // Question 5 -- Equality
    void equals(Tree *otherTree)
    {
        bool result = equals(root, otherTree->root);
        cout << (result ? "true" : "false") << endl;
    }
    bool equals(TreeNode *subtree1, TreeNode *subtree2)
    {

    }

    ////////////////////////////////////////////////////
    // Question 6 -- Distance
    void distance(int value1, int value2)
    {
        cout << distance(root, value1, value2) << endl;
    }
    int distance(TreeNode *subtree, int value1, int value2)
    {

    }
};

int main()
{
    // This function works correctly, don't change it unless you really need to.
    Tree t;

    int value;
    // Read and construct the tree.
    while (cin >> value && value != -1)
    {
        t.insert(value);
    }

    // Read a command
    string command;
    cin >> command;

    // Decide which command we saw and call that function
    if (command == "pre")
    {
        t.preOrderTraversal();
    }
    else if (command == "in")
    {
        t.inOrderTraversal();
    }
    else if (command == "post")
    {
        t.postOrderTraversal();
    }
    else if (command == "desc")
    {
        t.descendingOrder();
    }
    else if (command == "depth")
    {
        cin >> value;
        t.depth(value);
    }
    else if (command == "internal")
    {
        t.internalNodes();
    }
    else if (command == "equals")
    {
        Tree t2;
        while (cin >> value && value != -1)
        {
            t2.insert(value);
        }
        t.equals(&t2);
    }
    else if (command == "distance")
    {
        int value2;
        cin >> value >> value2;
        t.distance(value, value2);
    }
}
